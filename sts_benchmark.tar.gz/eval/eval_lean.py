#!/usr/bin/env python3
"""
Evaluate LLMs on Lean 4 infinite combo proofs.

Usage:
    python eval_lean.py --model openai/gpt-5.4
    python eval_lean.py --model openai/gpt-5.4 --thinking --parallel 10
    python eval_lean.py --combo 0  # single combo by index
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
FRAMEWORK_DIR = SCRIPT_DIR.parent
COMBOS_DIR = FRAMEWORK_DIR / "StSVerify" / "Combos"
PROMPT_TEMPLATE = SCRIPT_DIR / "prompt_template.txt"
RESULTS_DIR = SCRIPT_DIR / "results"
INDEX_PATH = COMBOS_DIR / "INDEX.md"


# ─── Load combos ──────────────────────────────────────────────────────────

# Combos excluded due to engine limitations (randomness, missing features)
EXCLUDED_COMBOS = {"ComboAllForOneMadness", "ComboMeditateRetain"}


def load_combos():
    """Load combo files from Combos directory, ordered by INDEX.md."""
    combos = []
    with open(INDEX_PATH) as f:
        for line in f:
            m = re.match(r'\|\s*(\d+)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|', line)
            if m and m.group(1).isdigit():
                idx = int(m.group(1))
                char = m.group(2).strip()
                name = m.group(3).strip()
                filename = m.group(4).strip()
                if filename.replace(".lean", "") in EXCLUDED_COMBOS:
                    continue
                filepath = COMBOS_DIR / filename
                if filepath.exists():
                    combos.append({
                        "index": idx,
                        "character": char,
                        "name": name,
                        "filename": filename,
                        "filepath": str(filepath),
                    })
    return combos


# ─── LLM interaction ─────────────────────────────────────────────────────

def call_llm(prompt, model, base_url=None, api_key=None, thinking=False, thinking_budget=None):
    from openai import OpenAI

    client = OpenAI(
        base_url=base_url or os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1"),
        api_key=api_key or os.environ.get("OPENAI_API_KEY", ""),
    )

    kwargs = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
    }

    if thinking:
        is_qwen = "qwen" in model.lower()
        if is_qwen:
            extra = {"enable_thinking": True}
            if thinking_budget is not None:
                extra["thinking_budget"] = thinking_budget
            kwargs["extra_body"] = extra
        else:
            reasoning = {"effort": "high"}
            if thinking_budget is not None:
                reasoning["max_tokens"] = thinking_budget
            kwargs["extra_body"] = {"reasoning": reasoning}
        kwargs["max_tokens"] = 128000
    else:
        kwargs["max_tokens"] = 16000

    response = client.chat.completions.create(**kwargs)
    content = response.choices[0].message.content

    # Extract thinking
    thinking_content = None
    think_match = re.search(r"<think>(.*?)</think>", content, flags=re.DOTALL)
    if think_match:
        thinking_content = think_match.group(1).strip()
        content = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL).strip()
    msg = response.choices[0].message
    msg_dict = msg.model_dump() if hasattr(msg, "model_dump") else {}
    for field in ("reasoning", "reasoning_content"):
        val = msg_dict.get(field) or getattr(msg, field, None)
        if val and isinstance(val, str):
            thinking_content = val
            break

    return content, thinking_content


# ─── Parse LLM response ──────────────────────────────────────────────────

def extract_balanced(text, start_pos, open_ch, close_ch):
    """Extract balanced bracket content starting from start_pos."""
    depth = 0
    i = start_pos
    while i < len(text):
        if text[i] == open_ch:
            depth += 1
        elif text[i] == close_ch:
            depth -= 1
            if depth == 0:
                return text[start_pos:i + 1]
        i += 1
    return text[start_pos:]  # unclosed — return rest


def extract_def(code, name, bracket_type):
    """Extract a definition from code. bracket_type: '[' for lists, '{' for structs."""
    close = ']' if bracket_type == '[' else '}'
    match = re.search(rf"def {name}\b[^=]*:=\s*", code)
    if not match:
        raise ValueError(f"Could not find 'def {name}' in LLM response")
    rest = code[match.end():]
    # Find the opening bracket
    idx = rest.find(bracket_type)
    if idx == -1:
        raise ValueError(f"Could not find '{bracket_type}' after 'def {name}'")
    content = extract_balanced(rest, idx, bracket_type, close)
    return f"def {name}{code[match.start()+len('def '+name):match.end()]}{content}"


def extract_lean_code(response):
    """Extract setupTrace, loopTrace, stateA, stateB from LLM response."""
    blocks = re.findall(r"```(?:lean4?|)\s*\n(.*?)```", response, re.DOTALL)
    code = "\n".join(blocks) if blocks else response

    setup = extract_def(code, "setupTrace", "[")
    loop = extract_def(code, "loopTrace", "[")
    stateA = extract_def(code, "stateA", "{")
    stateB = extract_def(code, "stateB", "{")

    return setup, loop, stateA, stateB


def inject_into_combo(combo_content, setup, loop, stateA, stateB):
    """Replace sorry placeholders with LLM-provided code."""
    result = combo_content
    result = re.sub(
        r"def setupTrace : List Action := \[\s*sorry\s*--[^\]]*\]",
        setup, result, flags=re.DOTALL)
    result = re.sub(
        r"def loopTrace : List Action := \[\s*sorry\s*--[^\]]*\]",
        loop, result, flags=re.DOTALL)
    result = re.sub(
        r"def stateA : GameState := sorry\s*--.*",
        stateA, result)
    result = re.sub(
        r"def stateB : GameState := sorry\s*--.*",
        stateB, result)
    return result


# ─── Lean verification ───────────────────────────────────────────────────

def verify_lean(combo_content, combo_filename, timeout=300):
    """Copy framework to temp dir, inject combo, run lake build."""
    with tempfile.TemporaryDirectory(prefix="lean_eval_") as tmpdir:
        # Copy framework
        src = str(FRAMEWORK_DIR)
        dst = tmpdir
        # Copy essential files
        for item in ["lakefile.toml", "lean-toolchain", "Main.lean", "StSVerify.lean"]:
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isfile(s):
                shutil.copy2(s, d)

        # Copy StSVerify directory (exclude Combos to save time)
        sts_src = os.path.join(src, "StSVerify")
        sts_dst = os.path.join(dst, "StSVerify")
        shutil.copytree(sts_src, sts_dst, ignore=shutil.ignore_patterns("Combos", "CombosSolution", "Demo.lean"))

        # Copy .lake build cache (avoids recompiling framework from scratch)
        lake_src = os.path.join(src, ".lake")
        lake_dst = os.path.join(dst, ".lake")
        if os.path.isdir(lake_src):
            shutil.copytree(lake_src, lake_dst, symlinks=True,
                            ignore=shutil.ignore_patterns("*.olean.tmp", "*.ilean.tmp"))

        # Write the combo file as the target
        combo_dir = os.path.join(sts_dst, "Combos")
        os.makedirs(combo_dir, exist_ok=True)
        target_path = os.path.join(combo_dir, combo_filename)
        with open(target_path, "w") as f:
            f.write(combo_content)

        # Write clean StSVerify.lean with only framework + this combo
        sts_lean = os.path.join(dst, "StSVerify.lean")
        module_name = combo_filename.replace(".lean", "")
        with open(sts_lean, "w") as f:
            f.write("import StSVerify.Basic\n")
            f.write("import StSVerify.CardDB\n")
            f.write(f"import StSVerify.Combos.{module_name}\n")

        # Build
        lean_bin = os.path.expanduser("~/.elan/bin")
        env = os.environ.copy()
        env["PATH"] = f"{lean_bin}:{env.get('PATH', '')}"

        cmd = ["lake", "build"]
        start = time.time()
        try:
            result = subprocess.run(
                cmd, cwd=dst, capture_output=True, text=True,
                timeout=timeout, env=env,
            )
            elapsed = time.time() - start
            output = (result.stdout or "") + "\n" + (result.stderr or "")
            return {
                "output": output,
                "returncode": result.returncode,
                "elapsed": elapsed,
                "timeout": False,
            }
        except subprocess.TimeoutExpired:
            return {
                "output": f"lake build timed out after {timeout}s",
                "returncode": -1,
                "elapsed": time.time() - start,
                "timeout": True,
            }


def soundness_check(lean_content):
    """Check for proof hacks: sorry, axiom, unsafe, instance, redefinitions.
    Returns (ok, issues) where issues is a list of problems found."""
    issues = []
    for i, line in enumerate(lean_content.split("\n"), 1):
        stripped = line.strip()
        # Skip comments
        if stripped.startswith("--"):
            continue
        # Check for sorry (outside comments)
        if re.search(r'\bsorry\b', stripped) and not stripped.startswith("--"):
            issues.append(f"Line {i}: contains 'sorry'")
        # Check for axiom declarations
        if re.match(r'\baxiom\b', stripped):
            issues.append(f"Line {i}: declares an axiom")
        # Check for unsafe
        if re.search(r'\bunsafe\b', stripped):
            issues.append(f"Line {i}: uses 'unsafe'")
        # Check for instance declarations (could introduce unsound Decidable)
        if re.match(r'\binstance\b', stripped):
            issues.append(f"Line {i}: declares an instance")
        # Check for redefining framework functions
        for fn in ["def execute ", "def step ", "def sameModAccum ", "def dealtDamage ",
                    "def normalizeState ", "def playCard ", "def drawCard ",
                    "def processEffect ", "def executeL2 ", "def stepL2 ",
                    "def drawCardL2 ", "def validOracle ", "def GuaranteedInfiniteCombo ",
                    "def InfiniteCombo ", "def mkInitialState ", "def loopCompleteBool ",
                    "def cardDB "]:
            if stripped.startswith(fn):
                issues.append(f"Line {i}: redefines framework function '{fn.strip()}'")
        # Check for extra imports (only Basic and CardDB allowed)
        if stripped.startswith("import ") and not any(
            ok in stripped for ok in ["StSVerify.Basic", "StSVerify.CardDB"]):
            issues.append(f"Line {i}: unauthorized import: {stripped}")
    return len(issues) == 0, issues


def classify_result(build_result, lean_content=None):
    """Classify build output."""
    output = build_result["output"]

    # Soundness checks on the generated Lean code
    if lean_content:
        ok, issues = soundness_check(lean_content)
        if not ok:
            return "HACK_DETECTED", "; ".join(issues)

    # Also check build output for sorry warnings
    if "declaration uses 'sorry'" in output:
        return "HACK_DETECTED", "Build output contains sorry warning"

    if build_result["timeout"]:
        return "TIMEOUT", "Lean build timed out"

    if build_result["returncode"] == 0 and "Build completed successfully" in output:
        return "PASS", "All theorems verified"

    if "native_decide" in output and "is false" in output:
        return "WRONG_TRACE", "Trace execution or loop check failed"

    if "declaration uses 'sorry'" in output and "uses 'sorry' and/or contains errors" in output:
        return "LEAN_ERROR", "Definition has errors (Lean fell back to sorry)"

    if "unknown identifier" in output or "expected" in output:
        return "SYNTAX_ERROR", "Generated Lean code has syntax errors"

    # Extract first error
    error_lines = [l.strip() for l in output.split("\n") if "error:" in l.lower()]
    detail = error_lines[0] if error_lines else output[:200]
    return "BUILD_ERROR", detail


# ─── Main ─────────────────────────────────────────────────────────────────

def evaluate_combo(combo, template, model, timeout, base_url, api_key, thinking, thinking_budget):
    """Full pipeline for one combo."""
    result = {
        "index": combo["index"],
        "character": combo["character"],
        "combo_name": combo["name"],
        "filename": combo["filename"],
        "model": model,
        "status": None,
        "detail": None,
        "elapsed_llm": None,
        "elapsed_build": None,
        "prompt": None,
        "llm_response": None,
        "llm_thinking": None,
        "trace_code": None,
        "final_code": None,
        "build_output": None,
        "error": None,
    }

    # Read combo file
    with open(combo["filepath"]) as f:
        combo_content = f.read()

    # Build prompt
    prompt = template.replace("{combo_file}", combo_content)

    result["prompt"] = prompt

    # Call LLM
    try:
        t0 = time.time()
        response, thinking_content = call_llm(
            prompt, model, base_url, api_key, thinking, thinking_budget
        )
        result["elapsed_llm"] = time.time() - t0
        result["llm_response"] = response
        result["llm_thinking"] = thinking_content
    except Exception as e:
        result["status"] = "LLM_ERROR"
        result["error"] = str(e)
        return result

    # Parse response
    try:
        setup, loop, stA, stB = extract_lean_code(response)
        result["extracted_code"] = {"setup": setup, "loop": loop, "stateA": stA, "stateB": stB}
    except ValueError as e:
        result["status"] = "PARSE_ERROR"
        result["error"] = str(e)
        return result

    # Inject into combo file
    try:
        filled = inject_into_combo(combo_content, setup, loop, stA, stB)
    except Exception as e:
        result["status"] = "INJECT_ERROR"
        result["error"] = str(e)
        return result

    # Verify with Lean
    build_result = verify_lean(filled, combo["filename"], timeout=timeout)
    result["elapsed_build"] = build_result["elapsed"]
    result["build_output"] = build_result["output"]

    status, detail = classify_result(build_result, lean_content=filled)
    result["status"] = status
    result["detail"] = detail

    return result


def print_summary(results):
    print(f"\n{'='*95}")
    print(f"{'#':>3} {'Character':<10} {'Combo':<30} {'Status':<14} {'LLM(s)':>8} {'Build(s)':>8}")
    print(f"{'-'*95}")

    status_counts = {}
    for r in results:
        s = r["status"]
        status_counts[s] = status_counts.get(s, 0) + 1
        llm = f"{r['elapsed_llm']:.1f}" if r["elapsed_llm"] else "-"
        bld = f"{r['elapsed_build']:.1f}" if r["elapsed_build"] else "-"
        name = r["combo_name"][:28]
        print(f"{r['index']:>3} {r['character']:<10} {name:<30} {s:<14} {llm:>8} {bld:>8}")

    print(f"{'='*95}")
    print(f"Total: {len(results)}  |  " + "  |  ".join(
        f"{k}: {v}" for k, v in sorted(status_counts.items())
    ))
    print()


def save_results(results, model, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    model_slug = model.split("/")[-1].replace(".", "").replace("-", "_")
    path = os.path.join(output_dir, f"lean_eval_{model_slug}_{timestamp}.json")
    with open(path, "w") as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=str)
    print(f"Results saved to: {path}")
    return path


def main():
    parser = argparse.ArgumentParser(description="Evaluate LLM Lean 4 proofs for StS infinite combos")
    parser.add_argument("--model", default="gpt-4o", help="Model name")
    parser.add_argument("--base-url", default=None, help="API base URL")
    parser.add_argument("--api-key", default=None, help="API key")
    parser.add_argument("--thinking", action="store_true", help="Enable extended thinking")
    parser.add_argument("--thinking-budget", type=int, default=None, help="Thinking token budget")
    parser.add_argument("--combo", default=None, help="Run single combo (index or name)")
    parser.add_argument("--parallel", type=int, default=5, help="Max parallel LLM calls")
    parser.add_argument("--timeout", type=int, default=300, help="Lean build timeout seconds")
    parser.add_argument("--output-dir", default=str(RESULTS_DIR), help="Results directory")
    parser.add_argument("--dry-run", action="store_true", help="Print prompts only")
    args = parser.parse_args()

    # Load
    combos = load_combos()
    template = PROMPT_TEMPLATE.read_text()

    # Filter
    if args.combo is not None:
        try:
            idx = int(args.combo)
            combos = [c for c in combos if c["index"] == idx]
        except ValueError:
            combos = [c for c in combos if args.combo in c["name"]]
        if not combos:
            print(f"No combo matching '{args.combo}'")
            sys.exit(1)

    print(f"Evaluating {len(combos)} combo(s) with {args.model}")
    print(f"Parallel: {args.parallel}, Build timeout: {args.timeout}s, Thinking: {args.thinking}")
    print()

    if args.dry_run:
        for combo in combos:
            with open(combo["filepath"]) as f:
                content = f.read()
            prompt = template.replace("{combo_file}", content)
            print(f"[{combo['index']}] {combo['character']} / {combo['name']}")
            print(f"  Prompt: {len(prompt)} chars")
        return

    # Run
    def run_one(combo):
        result = evaluate_combo(
            combo, template, args.model, args.timeout,
            args.base_url, args.api_key, args.thinking, args.thinking_budget,
        )
        icon = {"PASS": "+", "WRONG_TRACE": "-", "TIMEOUT": "!"}.get(result["status"], "X")
        print(f"[{result['index']:>2}] [{icon}] {result['character']} / {result['combo_name']}")
        print(f"     {result['status']}: {result.get('detail') or result.get('error', '')}", flush=True)
        return result

    results = [None] * len(combos)
    with ThreadPoolExecutor(max_workers=args.parallel) as pool:
        futures = {pool.submit(run_one, c): i for i, c in enumerate(combos)}
        for future in as_completed(futures):
            i = futures[future]
            results[i] = future.result()

    print_summary(results)
    save_results(results, args.model, args.output_dir)


if __name__ == "__main__":
    main()
